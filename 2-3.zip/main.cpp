#include <iostream>
using namespace std;
class Circle {
public:
  float *radius_;
  Circle(int ile) {
   radius_=new float[ile];
   cout << radius_ << endl;
  }
  ~Circle(void){
     delete [] radius_;
     cout <<"Usunięte";
  }
};

int main()
{

Circle nic(1);
 
}
