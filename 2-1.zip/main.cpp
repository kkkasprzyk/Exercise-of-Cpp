#include <iostream>
using namespace std;
class Circle {
public:
  float radius_;
};

int main()
{
 Circle nic , nic2;
 nic.radius_=5;
 nic2.radius_=7;
}
